<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-gray-100 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-black text-center text-2xl">
                    Kalendar
                    rezervacija<br><?php echo e(request()->get('date') ? Carbon\Carbon::parse(request()->get('date'))->format('d.m.Y.') : date('d.m.Y.')); ?>

                </div>
            </div>
        </div>
    </div>


    <form class="m-2" method="POST" action="<?php echo e(route('admin.calendar')); ?>">
        <?php echo csrf_field(); ?>
        <input class="bg-gray-100 text-black" type="date" name="date" id="name" onchange="this.form.submit()"
            placeholder="dd.mm.yyyy" value="<?php echo e(request()->get('date') ? request()->get('date') : date('Y-m-d')); ?>" />
    </form>



    <div class="grid grid-cols-2 gap-10">



        <!-- Each <div> is a single column.
        Place some content inside to see the effect. -->
        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Table responsive wrapper -->
            <div class="overflow-x-auto bg-white text-black">
                <div class="flex flex-col justify-center items-center">
                    <h1 class="text-2xl"><?php echo e($table->name); ?></h1>
                    <hr class="border-gray-800 w-full">
                </div>
                <!-- Table -->
                <table class="min-w-full text-left text-sm whitespace-nowrap text-black">

                    <!-- Table head -->
                    <thead class="uppercase tracking-wider border-b-2 ">
                        <tr>
                            <th scope="col" class="px-6 py-4">
                                Vrijeme
                            </th>
                            <th scope="col" class="px-6 py-4">
                                Ime
                            </th>
                            <th scope="col" class="px-6 py-4">
                                Prezime
                            </th>
                            <th scope="col" class="px-6 py-4">
                                Email
                            </th>
                            <th scope="col" class="px-6 py-4">
                                Telefon
                            </th>
                        </tr>
                    </thead>

                    <!-- Table body -->
                    <tbody>
                        <?php $__currentLoopData = $table->reservations->sortBy('res_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($reservation->res_date->format('Y-m-d') == (request()->get('date') ? request()->get('date') : date('Y-m-d'))): ?>
                                <tr class="border-b hover:bg-neutral-100">
                                    <th scope="row" class="px-6 py-4">
                                        <?php echo e($reservation->res_date->format('H:i')); ?>

                                    </th>
                                    <td class="px-6 py-4"><?php echo e($reservation->first_name); ?></td>
                                    <td class="px-6 py-4"><?php echo e($reservation->last_name); ?></td>
                                    <td class="px-6 py-4"><?php echo e($reservation->email); ?></td>
                                    <td class="px-6 py-4"><?php echo e($reservation->phone); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\resto-app\resources\views/admin/calendar.blade.php ENDPATH**/ ?>