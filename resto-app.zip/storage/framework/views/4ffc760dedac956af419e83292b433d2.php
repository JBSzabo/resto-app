<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-black leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>




    <div class="mx-auto max-w-2xl px-1 sm:px-1 lg:px-2 py-1 sm:py-2 lg:max-w-7xl  min-h-screen">
        <div class="grid grid-cols-1 gap-x-3 gap-y-5  lg:grid-cols-2 xl:grid-cols-2 xl:gap-x-4">

            <div class="flex-wrap basis-1/4 shadow-lg rounded-lg bg-gray-200 overflow-hidden h-fit">
                <div class="py-3 px-5 bg-gray-100 text-black text-center text-xl">Rezervacije ovaj tjedan</div>
                <canvas class="p-10 " id="resWeek"></canvas>
            </div>

            <div class="basis-1/4 shadow-lg rounded-lg bg-gray-200 overflow-hidden h-fit">
                <div class="py-3 px-5 bg-gray-100 text-black text-center text-xl">Rezervacije idući tjedan</div>
                <canvas class="p-10 " id="resNextWeek"></canvas>
            </div>

            <div class="basis-1/4 shadow-lg rounded-lg bg-gray-200 overflow-hidden h-fit">
                <div class="py-3 px-5 bg-gray-100 text-black text-center text-xl">Rezervirani stolovi ukupno</div>
                <canvas class="p-10" id="favTables"></canvas>
            </div>

            <div class="basis-1/4 shadow-lg rounded-lg bg-gray-200 overflow-hidden h-fit">
                <div class="py-3 px-5 bg-gray-100 text-black text-center text-xl ">Rezervacije po mjesecima</div>
                <canvas class="p-10 " id="resYear"></canvas>
            </div>


        </div>
    </div>





    <!-- Required chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Chart bar -->
    <script>
        Chart.defaults.color = '#000';




        const labelsBarChartYear = [
            "Siječanj",
            "Veljača",
            "Ožujak",
            "Travanj",
            "Svibanj",
            "Lipanj",
            "Srpanj",
            "Kolovoz",
            "Rujan",
            "Listopad",
            "Studeni",
            "Prosinac",
        ];
        const dataBarChartYear = {
            labels: labelsBarChartYear,
            datasets: [{
                label: "Broj rezervacija",
                data: <?php echo json_encode($chart_data); ?>,
                borderColor: '#baffc9',
                backgroundColor: '#00b159',
            }, ],
        };
        const configBarChartYear = {
            type: "line",
            data: dataBarChartYear,
            options: {},
        };
        var chartBarYear = new Chart(
            document.getElementById("resYear"),
            configBarChartYear
        );


        const dataBarChartWeek = {
            labels: <?php echo json_encode($dates); ?>,
            datasets: [{
                label: "Broj rezervacija",
                data: <?php echo json_encode($this_week); ?>,
                borderColor: '#FF6384',
                backgroundColor: '#ffdfba',
            }, ],
        };
        const configBarChartWeek = {
            type: "bar",
            data: dataBarChartWeek,
            options: {},
        };
        var chartBarWeek = new Chart(
            document.getElementById("resWeek"),
            configBarChartWeek
        );



        const dataBarChartNextWeek = {
            labels: <?php echo json_encode($dates_next); ?>,
            datasets: [{
                label: "Broj rezervacija",
                data: <?php echo json_encode($next_week); ?>,
                borderColor: '#FF8811',
                backgroundColor: '#f37735',
            }, ],
        };
        const configBarChartNextWeek = {
            type: "bar",
            data: dataBarChartNextWeek,
            options: {},
        };
        var chartBarNextWeek = new Chart(
            document.getElementById("resNextWeek"),
            configBarChartNextWeek
        );

        const dataBarChartTable = {
            labels: <?php echo json_encode($table_names); ?>,
            datasets: [{
                label: "Broj rezervacija",
                data: <?php echo json_encode($table_count); ?>,
            }, ],
        };
        const configBarChartTable = {
            type: "pie",
            data: dataBarChartTable,
            options: {},
        };
        var chartBarTable = new Chart(
            document.getElementById("favTables"),
            configBarChartTable
        );
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\resto-app\resources\views/admin/index.blade.php ENDPATH**/ ?>