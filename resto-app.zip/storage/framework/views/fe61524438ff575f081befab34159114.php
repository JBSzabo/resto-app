<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white">
        <div class="mx-auto max-w-2xl text-center mt-24">
            <h2 class="text-5xl font-normal leading-normal mt-0 mb-2 text-blueGray-800"><?php echo e($category->name); ?></h2>
            <hr class="my-12 h-0.5 border-t-0 bg-black opacity-100" />
        </div>
        <div class="mx-auto max-w-2xl px-4 py-4 mb-36 sm:px-6 sm:py-6 lg:max-w-7xl lg:px-8">


            <a href="<?php echo e(route('categories.index')); ?>" role="button"
                class="inline-block rounded border-2 border-black text-black hover:border-black hover:bg-black duration-200 hover:text-white px-6 gap-x-2 pb-2 pt-2.5 text-sm font-bold uppercase transition ease-in-out">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                    class="inline ml-1 pb-[2px] w-5 h-5 ">
                    <path fill-rule="evenodd" d="M6.75 15.75L3 12m0 0l3.75-3.75M3 12h18" clip-rule="evenodd"
                        stroke-width="1.5" stroke="currentColor" />
                </svg>Povratak
            </a>


            <div class="mt-6 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">


                <?php $__currentLoopData = $category->meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative flex flex-col text-gray-700 bg-white shadow-md bg-clip-border rounded-xl w-96">
                        <div
                            class="relative mx-4 mt-4 overflow-hidden text-gray-700 bg-white bg-clip-border rounded-xl h-96">
                            <img src="<?php echo e(Storage::url($meal->image)); ?>" alt="card-image" class=" h-full" />
                        </div>
                        <div class="p-6">
                            <div class="flex items-center justify-between mb-2">
                                <p class="block font-sans antialiased text-2xl  text-blue-black">
                                    <?php echo e($meal->name); ?>

                                </p>
                                <p class="block font-sans antialiased text-xl  text-blue-gray-900">
                                    <?php echo e($meal->price); ?> €
                                </p>
                            </div>
                            <p class="block font-sans antialiased text-lg  text-gray-800 ">
                                <?php echo e($meal->description); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\resto-app\resources\views/categories/show.blade.php ENDPATH**/ ?>