<?php

namespace App\Enums;

enum TableLocation: string
{
    case Vani = 'outside';
    case Unutra = 'inside';
}
