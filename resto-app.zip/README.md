# resto-app

Restaurant rebuilt using Laravel

TODO:

-   Add icons to admin dashboard

-   Dark theme

-   Mail confirmation

-   Locale switch
