<?php

declare(strict_types=1);

return [
    'failed'   => 'Ovi podaci ne odgovaraju našima.',
    'password' => 'Lozinka je pogrešna.',
    'throttle' => 'Previše pokušaja prijave. Molim Vas pokušajte ponovno za :seconds sekundi.',
];
